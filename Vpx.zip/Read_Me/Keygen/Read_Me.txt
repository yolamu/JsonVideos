
Disconnect from Internet
� Run Setup.
� Run the Keygen.
� Copy the Key.
� Past it on reg from and use any name, email.
� That�s it. Enjoy


BabuPC.COM