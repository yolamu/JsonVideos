Patch,

Disconnect from Internet
� Run Setup.
� Run the patch
� Copy the patch File into install directory.
� That�s it. Enjoy

BabuPC.COM