Disconnect from Internet
� Run Setup.
� Copy the Crack file.
� Past it on the c drive apps folder.
� That�s it. Enjoy

BabuPC.COM